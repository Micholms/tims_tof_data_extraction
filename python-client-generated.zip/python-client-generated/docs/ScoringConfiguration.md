# ScoringConfiguration

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mz_wide** | **float** |  | 
**mz_narrow** | **float** |  | 
**mz_unit** | **str** |  | 
**rt_in_seconds_narrow** | **float** |  | [optional] 
**rt_in_seconds_wide** | **float** |  | [optional] 
**ms_ms_wide** | **float** |  | [optional] 
**ms_ms_narrow** | **float** |  | [optional] 
**ccs_wide** | **float** |  | [optional] 
**ccs_narrow** | **float** |  | [optional] 
**msigma_narrow** | **float** |  | [optional] 
**msigma_wide** | **float** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

