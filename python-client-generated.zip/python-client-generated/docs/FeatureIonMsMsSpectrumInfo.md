# FeatureIonMsMsSpectrumInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**feature_id** | **str** |  | [optional] 
**feature_ion** | [**FeatureIon**](FeatureIon.md) |  | [optional] 
**spectra** | [**list[MsMsSpectrum]**](MsMsSpectrum.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

