# Chromatogram

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**rts_in_seconds** | **list[float]** |  | [optional] 
**intensities** | **list[float]** |  | [optional] 
**analysis_id** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

