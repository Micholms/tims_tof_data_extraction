# FeatureMatrix

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**intensities** | **list[list[float]]** |  | [optional] 
**feature_ids** | **list[str]** |  | [optional] 
**analysis_ids** | **list[str]** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

