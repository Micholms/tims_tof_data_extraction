# AnnotationDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**annotation** | [**Annotation**](Annotation.md) |  | [optional] 
**main_ion_notation** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

