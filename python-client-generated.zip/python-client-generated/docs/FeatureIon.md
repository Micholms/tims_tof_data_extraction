# FeatureIon

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ion_notation** | **str** |  | [optional] 
**mz** | **float** |  | [optional] 
**ccs** | **float** |  | [optional] 
**id** | **str** |  | [optional] 
**main_ion** | **bool** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

