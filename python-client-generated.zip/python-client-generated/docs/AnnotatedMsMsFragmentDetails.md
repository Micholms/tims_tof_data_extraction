# AnnotatedMsMsFragmentDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**fragment_ion_formula** | **str** |  | [optional] 
**accurate_mz** | **float** |  | [optional] 
**ms_ms_spectrum_id** | **str** |  | [optional] 
**ms_ms_rule_type** | **str** |  | [optional] 
**lipid_identity_level** | **str** |  | [optional] 
**chain_information** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

