# AnnotationConfiguration

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ions_for_reassignment** | **list[str]** |  | [optional] 
**main_ion_infos** | [**list[MainIonDetails]**](MainIonDetails.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

