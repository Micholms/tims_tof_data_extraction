# swagger_client.FeaturetableApi

All URIs are relative to */*

Method | HTTP request | Description
------------- | ------------- | -------------
[**add_flag_to_feature**](FeaturetableApi.md#add_flag_to_feature) | **POST** /featuretable/feature/{featureId}/flag/create | 
[**create_annotation**](FeaturetableApi.md#create_annotation) | **POST** /featuretable/feature/{featureId}/annotation/create | 
[**create_feature_table**](FeaturetableApi.md#create_feature_table) | **POST** /featuretable/create | Create a new Feature Table
[**create_lipid_species_annotations_with_method**](FeaturetableApi.md#create_lipid_species_annotations_with_method) | **POST** /featuretable/annotation/create/lipidspecies/{annotationMethodUuid} | 
[**create_target_list_annotations_with_method**](FeaturetableApi.md#create_target_list_annotations_with_method) | **POST** /featuretable/annotation/create/targetlist/{annotationMethodUuid} | 
[**delete_annotation**](FeaturetableApi.md#delete_annotation) | **POST** /featuretable/feature/{featureId}/annotation/delete/{annotationId} | 
[**generate_new_eics_and_eims**](FeaturetableApi.md#generate_new_eics_and_eims) | **POST** /featuretable/{featureTableId}/eicsandeims/create | 
[**remove_flag_from_feature**](FeaturetableApi.md#remove_flag_from_feature) | **POST** /featuretable/feature/{featureId}/flag/remove | 
[**retrieve_annotation_configuration_by_id**](FeaturetableApi.md#retrieve_annotation_configuration_by_id) | **GET** /featuretable/annotation/configuration/{configurationId} | 
[**retrieve_annotation_methods_by_tool_id**](FeaturetableApi.md#retrieve_annotation_methods_by_tool_id) | **GET** /featuretable/annotation/methods/{toolId} | 
[**retrieve_eics_for_feature**](FeaturetableApi.md#retrieve_eics_for_feature) | **GET** /featuretable/feature/{featureId}/eics | 
[**retrieve_eims_for_feature**](FeaturetableApi.md#retrieve_eims_for_feature) | **GET** /featuretable/feature/{featureId}/eims | 
[**retrieve_feature**](FeaturetableApi.md#retrieve_feature) | **GET** /featuretable/feature/{featureId} | 
[**retrieve_feature_ion_ms_spectra**](FeaturetableApi.md#retrieve_feature_ion_ms_spectra) | **GET** /featuretable/feature/{featureId}/ms | 
[**retrieve_feature_ms_ms_spectra**](FeaturetableApi.md#retrieve_feature_ms_ms_spectra) | **GET** /featuretable/feature/{featureId}/msms | 
[**retrieve_feature_ms_ms_spectra_deiso**](FeaturetableApi.md#retrieve_feature_ms_ms_spectra_deiso) | **GET** /featuretable/feature/{featureId}/msmsdeiso | 
[**retrieve_feature_ms_spectra_details**](FeaturetableApi.md#retrieve_feature_ms_spectra_details) | **GET** /featuretable/feature/{featureId}/ms/details | 
[**retrieve_feature_table**](FeaturetableApi.md#retrieve_feature_table) | **GET** /featuretable/{featureTableId} | 
[**retrieve_intensity_matrix**](FeaturetableApi.md#retrieve_intensity_matrix) | **GET** /featuretable/intensitymatrix/{featureTableId} | 
[**save_new_annotation_configuration**](FeaturetableApi.md#save_new_annotation_configuration) | **POST** /featuretable/{featureTableId}/annotation/configuration/save | 

# **add_flag_to_feature**
> add_flag_to_feature(feature_id, flag=flag)



### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.FeaturetableApi()
feature_id = 'feature_id_example' # str | 
flag = 'flag_example' # str |  (optional)

try:
    api_instance.add_flag_to_feature(feature_id, flag=flag)
except ApiException as e:
    print("Exception when calling FeaturetableApi->add_flag_to_feature: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **feature_id** | **str**|  | 
 **flag** | **str**|  | [optional] 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **create_annotation**
> create_annotation(feature_id, body=body)



### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.FeaturetableApi()
feature_id = 'feature_id_example' # str | 
body = swagger_client.AnnotationCandidate() # AnnotationCandidate |  (optional)

try:
    api_instance.create_annotation(feature_id, body=body)
except ApiException as e:
    print("Exception when calling FeaturetableApi->create_annotation: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **feature_id** | **str**|  | 
 **body** | [**AnnotationCandidate**](AnnotationCandidate.md)|  | [optional] 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **create_feature_table**
> ProjectTaskSummary create_feature_table(body)

Create a new Feature Table

Initiates the creation of a Feature Table by processing the provided project YAML. This YAML should define the project's structure, including details about experiments and feature tables.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.FeaturetableApi()
body = 'body_example' # str | The YAML file that defines the structure and details of the project, including one experiment and one Feature Table. The Project ID and Experiment ID are mandatory to create a Feature Table!

try:
    # Create a new Feature Table
    api_response = api_instance.create_feature_table(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling FeaturetableApi->create_feature_table: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**str**](str.md)| The YAML file that defines the structure and details of the project, including one experiment and one Feature Table. The Project ID and Experiment ID are mandatory to create a Feature Table! | 

### Return type

[**ProjectTaskSummary**](ProjectTaskSummary.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: text/plain
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **create_lipid_species_annotations_with_method**
> list[AnnotationDetails] create_lipid_species_annotations_with_method(annotation_method_uuid, body=body)



### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.FeaturetableApi()
annotation_method_uuid = 'annotation_method_uuid_example' # str | 
body = swagger_client.AnnotationConfiguration() # AnnotationConfiguration |  (optional)

try:
    api_response = api_instance.create_lipid_species_annotations_with_method(annotation_method_uuid, body=body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling FeaturetableApi->create_lipid_species_annotations_with_method: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **annotation_method_uuid** | **str**|  | 
 **body** | [**AnnotationConfiguration**](AnnotationConfiguration.md)|  | [optional] 

### Return type

[**list[AnnotationDetails]**](AnnotationDetails.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **create_target_list_annotations_with_method**
> list[AnnotationDetails] create_target_list_annotations_with_method(annotation_method_uuid, body=body)



### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.FeaturetableApi()
annotation_method_uuid = 'annotation_method_uuid_example' # str | 
body = swagger_client.AnnotationConfiguration() # AnnotationConfiguration |  (optional)

try:
    api_response = api_instance.create_target_list_annotations_with_method(annotation_method_uuid, body=body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling FeaturetableApi->create_target_list_annotations_with_method: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **annotation_method_uuid** | **str**|  | 
 **body** | [**AnnotationConfiguration**](AnnotationConfiguration.md)|  | [optional] 

### Return type

[**list[AnnotationDetails]**](AnnotationDetails.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **delete_annotation**
> delete_annotation(feature_id, annotation_id)



### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.FeaturetableApi()
feature_id = 'feature_id_example' # str | 
annotation_id = 'annotation_id_example' # str | 

try:
    api_instance.delete_annotation(feature_id, annotation_id)
except ApiException as e:
    print("Exception when calling FeaturetableApi->delete_annotation: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **feature_id** | **str**|  | 
 **annotation_id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **generate_new_eics_and_eims**
> generate_new_eics_and_eims(feature_table_id, body=body)



### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.FeaturetableApi()
feature_table_id = 'feature_table_id_example' # str | 
body = ['body_example'] # list[str] |  (optional)

try:
    api_instance.generate_new_eics_and_eims(feature_table_id, body=body)
except ApiException as e:
    print("Exception when calling FeaturetableApi->generate_new_eics_and_eims: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **feature_table_id** | **str**|  | 
 **body** | [**list[str]**](str.md)|  | [optional] 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **remove_flag_from_feature**
> remove_flag_from_feature(feature_id, flag=flag)



### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.FeaturetableApi()
feature_id = 'feature_id_example' # str | 
flag = 'flag_example' # str |  (optional)

try:
    api_instance.remove_flag_from_feature(feature_id, flag=flag)
except ApiException as e:
    print("Exception when calling FeaturetableApi->remove_flag_from_feature: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **feature_id** | **str**|  | 
 **flag** | **str**|  | [optional] 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **retrieve_annotation_configuration_by_id**
> AnnotationToolConfiguration retrieve_annotation_configuration_by_id(configuration_id)



### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.FeaturetableApi()
configuration_id = 'configuration_id_example' # str | 

try:
    api_response = api_instance.retrieve_annotation_configuration_by_id(configuration_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling FeaturetableApi->retrieve_annotation_configuration_by_id: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **configuration_id** | **str**|  | 

### Return type

[**AnnotationToolConfiguration**](AnnotationToolConfiguration.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **retrieve_annotation_methods_by_tool_id**
> list[AnnotationMethod] retrieve_annotation_methods_by_tool_id(tool_id)



### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.FeaturetableApi()
tool_id = 'tool_id_example' # str | 

try:
    api_response = api_instance.retrieve_annotation_methods_by_tool_id(tool_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling FeaturetableApi->retrieve_annotation_methods_by_tool_id: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tool_id** | **str**|  | 

### Return type

[**list[AnnotationMethod]**](AnnotationMethod.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **retrieve_eics_for_feature**
> list[FeatureEics] retrieve_eics_for_feature(feature_id)



### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.FeaturetableApi()
feature_id = 'feature_id_example' # str | 

try:
    api_response = api_instance.retrieve_eics_for_feature(feature_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling FeaturetableApi->retrieve_eics_for_feature: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **feature_id** | **str**|  | 

### Return type

[**list[FeatureEics]**](FeatureEics.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **retrieve_eims_for_feature**
> list[FeatureEims] retrieve_eims_for_feature(feature_id)



### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.FeaturetableApi()
feature_id = 'feature_id_example' # str | 

try:
    api_response = api_instance.retrieve_eims_for_feature(feature_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling FeaturetableApi->retrieve_eims_for_feature: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **feature_id** | **str**|  | 

### Return type

[**list[FeatureEims]**](FeatureEims.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **retrieve_feature**
> Feature retrieve_feature(feature_id)



### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.FeaturetableApi()
feature_id = 'feature_id_example' # str | 

try:
    api_response = api_instance.retrieve_feature(feature_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling FeaturetableApi->retrieve_feature: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **feature_id** | **str**|  | 

### Return type

[**Feature**](Feature.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **retrieve_feature_ion_ms_spectra**
> list[FeatureIonMsSpectrumInfo] retrieve_feature_ion_ms_spectra(feature_id)



### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.FeaturetableApi()
feature_id = 'feature_id_example' # str | 

try:
    api_response = api_instance.retrieve_feature_ion_ms_spectra(feature_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling FeaturetableApi->retrieve_feature_ion_ms_spectra: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **feature_id** | **str**|  | 

### Return type

[**list[FeatureIonMsSpectrumInfo]**](FeatureIonMsSpectrumInfo.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **retrieve_feature_ms_ms_spectra**
> list[FeatureIonMsMsSpectrumInfo] retrieve_feature_ms_ms_spectra(feature_id)



### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.FeaturetableApi()
feature_id = 'feature_id_example' # str | 

try:
    api_response = api_instance.retrieve_feature_ms_ms_spectra(feature_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling FeaturetableApi->retrieve_feature_ms_ms_spectra: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **feature_id** | **str**|  | 

### Return type

[**list[FeatureIonMsMsSpectrumInfo]**](FeatureIonMsMsSpectrumInfo.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **retrieve_feature_ms_ms_spectra_deiso**
> list[FeatureIonMsMsSpectrumInfo] retrieve_feature_ms_ms_spectra_deiso(feature_id)



### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.FeaturetableApi()
feature_id = 'feature_id_example' # str | 

try:
    api_response = api_instance.retrieve_feature_ms_ms_spectra_deiso(feature_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling FeaturetableApi->retrieve_feature_ms_ms_spectra_deiso: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **feature_id** | **str**|  | 

### Return type

[**list[FeatureIonMsMsSpectrumInfo]**](FeatureIonMsMsSpectrumInfo.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **retrieve_feature_ms_spectra_details**
> list[FeatureIonMsSpectrumInfo] retrieve_feature_ms_spectra_details(feature_id)



### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.FeaturetableApi()
feature_id = 'feature_id_example' # str | 

try:
    api_response = api_instance.retrieve_feature_ms_spectra_details(feature_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling FeaturetableApi->retrieve_feature_ms_spectra_details: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **feature_id** | **str**|  | 

### Return type

[**list[FeatureIonMsSpectrumInfo]**](FeatureIonMsSpectrumInfo.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **retrieve_feature_table**
> list[Feature] retrieve_feature_table(feature_table_id)



### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.FeaturetableApi()
feature_table_id = 'feature_table_id_example' # str | 

try:
    api_response = api_instance.retrieve_feature_table(feature_table_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling FeaturetableApi->retrieve_feature_table: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **feature_table_id** | **str**|  | 

### Return type

[**list[Feature]**](Feature.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **retrieve_intensity_matrix**
> FeatureMatrix retrieve_intensity_matrix(feature_table_id)



### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.FeaturetableApi()
feature_table_id = 'feature_table_id_example' # str | 

try:
    api_response = api_instance.retrieve_intensity_matrix(feature_table_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling FeaturetableApi->retrieve_intensity_matrix: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **feature_table_id** | **str**|  | 

### Return type

[**FeatureMatrix**](FeatureMatrix.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **save_new_annotation_configuration**
> str save_new_annotation_configuration(feature_table_id, body=body)



### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.FeaturetableApi()
feature_table_id = 'feature_table_id_example' # str | 
body = swagger_client.AnnotationToolConfiguration() # AnnotationToolConfiguration |  (optional)

try:
    api_response = api_instance.save_new_annotation_configuration(feature_table_id, body=body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling FeaturetableApi->save_new_annotation_configuration: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **feature_table_id** | **str**|  | 
 **body** | [**AnnotationToolConfiguration**](AnnotationToolConfiguration.md)|  | [optional] 

### Return type

**str**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

