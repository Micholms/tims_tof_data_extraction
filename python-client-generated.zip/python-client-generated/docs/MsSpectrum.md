# MsSpectrum

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**signals** | [**list[Signal]**](Signal.md) |  | [optional] 
**analysis_id** | **str** |  | [optional] 
**mean_measured_mz** | **float** |  | [optional] 
**rt_in_seconds** | **float** |  | [optional] 
**ccs** | **float** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

