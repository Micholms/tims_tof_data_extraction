# AQScores

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mz_aq_score** | **int** |  | [optional] 
**rt_aq_score** | **int** |  | [optional] 
**isotope_pattern_aq_score** | **int** |  | [optional] 
**msms_aq_score** | **int** |  | [optional] 
**ccs_aq_score** | **int** |  | [optional] 
**mz_deviation** | **float** |  | [optional] 
**rt_deviation** | **float** |  | [optional] 
**isotope_pattern_score** | **float** |  | [optional] 
**msms_score** | **float** |  | [optional] 
**ccs_deviation** | **float** |  | [optional] 
**annotation_modifiers** | **list[str]** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

