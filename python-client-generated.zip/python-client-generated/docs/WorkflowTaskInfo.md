# WorkflowTaskInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**workflow_task_id** | **str** |  | [optional] 
**status** | **str** |  | [optional] 
**task_infos** | [**list[TaskInfo]**](TaskInfo.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

